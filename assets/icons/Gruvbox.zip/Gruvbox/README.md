# Gruvbox icon theme 

This icon set is based on the theme of gruvbox colors for vim [https://github.com/morhetz/gruvbox](https://github.com/morhetz/gruvbox).

We adapt the colors of all the icons for the new scheme.

The original application icons are from the Papirus icon set [github](https://github.com/PapirusDevelopmentTeam/papirus-icon-theme), [pling.com](https://www.pling.com/p/1166289/).


All other icons are inherited by the theme Papirus (which we kindly recommend using).

Thanks to:

KDE team
Papirus Development Team
